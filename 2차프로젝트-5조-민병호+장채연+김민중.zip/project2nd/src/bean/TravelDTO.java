package bean;

public class TravelDTO {
   private String name;
   private String region;
   private String place;
   private String theme;
   private String member;
   private String picture;
   
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getRegion() {
      return region;
   }
   public void setRegion(String region) {
      this.region = region;
   }
   public String getPlace() {
      return place;
   }
   public void setPlace(String place) {
      this.place = place;
   }
   public String getTheme() {
      return theme;
   }
   public void setTheme(String theme) {
      this.theme = theme;
   }
   public String getMember() {
      return member;
   }
   public void setMember(String member) {
      this.member = member;
   }
   public String getPicture() {
      return picture;
   }
   public void setPicture(String picture) {
      this.picture = picture;
   }
   
}